package com.tech.parking.listeners;

public interface OnItemClick<T> {
        void onCLick(T item);
    }