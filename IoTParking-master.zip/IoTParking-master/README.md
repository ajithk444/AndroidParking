<dev>
  <p># IoT based Parking system</p>
  <img height='100' width='100' src='app/src/main/res/drawable/app_parking.png' />
  </dev>

<br/>
  <p>Sample Screens</p>
  <img height='100' width='100' src='app/src/main/res/drawable/login.png' />
  