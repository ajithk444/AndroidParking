package com.tech.parking.ocr;

public interface QRDataListener {

    void onDetected(final String data);
}