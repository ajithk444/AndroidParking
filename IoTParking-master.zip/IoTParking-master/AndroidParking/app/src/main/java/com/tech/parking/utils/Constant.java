package com.tech.parking.utils;

public class Constant {

    public static final String ITEM_CARS = "Cars";
    public static final String ITEM_BOOKING = "Current Booking";
    public static final String ITEM_WALLET = "Wallet";
    public static final String ITEM_LOGOUT = "Logout";
    public static final String ITEM_HOME = "Home";
    public static final String ITEM_PARKING = "Parking";
    public static final String ITEM_SPACES = "Spaces";
    public static final String ITEM_USERS = "Users";
    public static final String ITEM_QR_READER = "Reader";

}
