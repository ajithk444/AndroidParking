package com.tech.parking.beans;

public enum BookingState {
    ACTIVE, STOP
}
