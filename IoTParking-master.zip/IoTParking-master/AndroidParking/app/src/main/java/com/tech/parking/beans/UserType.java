package com.tech.parking.beans;

public enum UserType {
    ADMIN, USER , accuntent
}
