
# IoT based smart parking system for android

Application includes below:
  - Clients with android application
  - Admin Panel with Android application to manage Parking, Space and Payments
  - Database technology Google Firebase
